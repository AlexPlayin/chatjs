var express = require('express'),
    chatio = require('./chat-io-server'),
    chat = chatio.Chat(8080),
    app = express(),
    server = require('http').createServer(app),
    conf = require('./config/config.json');

// Webserver
// auf den Port x schalten
server.listen(conf.siteport);




app.use(express.static(__dirname + '/public'));

// wenn der Pfad / aufgerufen wird
app.get('/', function (req, res) {
    // so wird die Datei index.html ausgegeben
    res.sendfile(__dirname + '/public/index.html');
});

app.post('/login/post', function (req, res) {

    var username = req.username;
    var password = req.password;



});