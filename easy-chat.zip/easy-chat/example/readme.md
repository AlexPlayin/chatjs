This is a running example for Easy-Chat.
