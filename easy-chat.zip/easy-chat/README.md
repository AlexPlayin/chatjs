# easy-chat
An easy to use and highly costumable node.js and javascript web chat application !!! IN DEVELOPMENT !!!
