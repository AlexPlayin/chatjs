var express = require('express'),
    chatio = require('./chat-io-server'),
    chat = chatio.Chat(8080),
    app = express(),
    server = require('http').createServer(app),
    mongoose = require('mongoose'),
    conf = require('./config/config.json');

// Webserver
// auf den Port x schalten
server.listen(conf.siteport);

mongoose.connect('mongodb://localhost/chatjs');
var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function () {
    console.log("[REGISTER] Mongoose Connection established!");
});


var Schema = mongoose.Schema;

// create a schema
var userSchema = new Schema({
    username: String,
    password: String,
    token: String
}, {
    collection: 'users'
});

// the schema is useless so far
// we need to create a model using it
var User = mongoose.model('users', userSchema);


app.use(express.static(__dirname + '/public'));

// wenn der Pfad / aufgerufen wird
app.get('/', function (req, res) {
    // so wird die Datei index.html ausgegeben
    res.sendfile(__dirname + '/public/index.html');
});

app.post('/login/post', function (req, res) {

    var username = req.username;
    var password = req.password;

});

app.post('/register/post', function (req, res) {

    var username = req.query.username;
    var password = req.query.password;

    var newUser = User({
        username: username,
        password: password
    });

    newUser.save(function (err) {
        if (err) throw err;

        console.log('[REGISTER] New user ' + username + ' was created.');
    });

});